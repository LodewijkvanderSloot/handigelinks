<html>
    <header>
        <title>Handige Links</title>
        <style type="text/css">
            body {background-color:lightblue; margin: 0px}
            h1 {font-family: Corbel; font-size: 12pt; font-weight: bold; color: darkblue; margin-bottom:0px; margin-left: 5px}
            h2 {font-family: Corbel; font-size: 12pt; font-weight: normal; color: darkblue; margin-bottom:0px; margin-left: 5px}
            hr {border-top:0;border-bottom:1px solid darkblue;margin-top:0px}
            a {font-family: Corbel; font-size: 10pt; font-weight: normal; color: darkblue; margin-left:20px}
            a:hover {font-family: Corbel; font-size: 10pt; font-weight: normal; color: black; margin-left:20px}
            ul.menu {background-color: darkblue;list-style-type: none;overflow: hidden; position: sticky;top: 0px;}
            li.menu {float:right}
            li.menu a {display: block; font-family: corbel; font-size: 12pt; font-weight: bold;padding: 10px;text-decoration: none; color: lightblue;}
            li.actief {float:left}
            li.actief a {display: block; font-family: corbel; font-size: 12pt; font-weight: bold;padding: 10px;text-decoration: none; color: darkblue; background-color: lightblue;}
            p {font-family: Corbel; font-size: 10pt; font-weight: normal; color: darkblue; margin-left:20px}
            ul {font-family: Corbel; font-size: 10pt; font-weight: normal; color: darkblue;}
            label {font-family: corbel; font-size: 12pt; font-weight: bold;color: darkblue; margin-left: 20px}
            a.small {text-align:right; font-family:corbel; font-size:8pt; color:darkblue; text-decoration:none;margin-left:5px}
            a.small:hover {text-align:right; font-family:corbel; font-size:8pt; color:black; text-decoration:none;margin-left:5px}
            .help-block {color:red;font-variant: small-caps;font-family:corbel;font-size:10pt}
            .form-group {margin-bottom: 5px;border:1px solid purple;width:500px}
        </style>
    </header>